#!/bin/bash

# check if at least one number is given
if [[ $# -lt 1 ]]; then
    echo "enter number"
    exit 1
fi

min=$1
max=$1

for i in "$@"; do
    if [[ $i -lt $min ]]; then
        min=$i
    fi
    if [[ $i -gt $max ]]; then
        max=$i
    fi
done

echo "Maximum: $max | Minimum: $min"

