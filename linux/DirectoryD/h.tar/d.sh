
n=$1
sed '/^[0-9]/s/gamma/delta/' "$n" 
