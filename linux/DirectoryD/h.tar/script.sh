#!/bin/bash

l=$(wc -l <"$1")

if [[ $l -lt 16 ]]; then
echo "No"
else 
echo "Yes"
fi


