#!/bin/bash

n=$1

prime=0

for (( i=2;i<$n;i++ )); do
if (( n%i==0 )); then
prime=1
break
fi
done
echo "$prime"
