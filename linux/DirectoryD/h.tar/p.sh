#!/bin/bash

n=$1

if [[ $n -lt 0 ]]; then
echo "NNUM"
else
echo "PNUM"
fi

