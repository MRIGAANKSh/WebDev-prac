#!/bin/bash

tar -cf h.tar *.sh 2>>e.txt

