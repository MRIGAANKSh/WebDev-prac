#!/bin/bash


index=1
for i in "$@"; do
if (( index %2==1 )); then
echo "$i "
fi
((index++))
done 
