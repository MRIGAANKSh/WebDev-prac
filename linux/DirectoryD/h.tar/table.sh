#!/bin/bash

if [[ $# -lt 2 ]]; then
echo "worng"
exit 1
fi

n=$1
t=$2

for((i=1;i<=t;i++)); do
s=$(($n*$i))
echo "$n*$i=$s"
echo ""
done 

