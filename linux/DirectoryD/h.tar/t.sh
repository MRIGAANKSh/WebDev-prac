#!/bin/bash

f=$1
if [[ -e "$f" ]]; then
p=$(stat -c "%A" "$f")
if [[ "$p" == "-r--------" ]]; then
echo "Yes"
else
echo "No"
fi

fi
