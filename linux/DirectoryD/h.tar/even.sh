#!/bin/bash

read -a number_arr

sum=0
for num in "${number_arr[@]}"; do
if (( num%2==0 )); then
sum=$((sum+num))
fi
done
echo "$sum"
