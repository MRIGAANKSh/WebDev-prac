#!/bin/bash

n=$1
t=$2

if [[ $# -ne 2 ]]; then
echo "Error"
else

sum=$(($n+$t))
echo "$sum"
fi

