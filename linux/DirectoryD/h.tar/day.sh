#!/bin/bash

n=$1

case $1 in 

1,8) echo "Sunday" ;;
2) echo "Monday" ;;
3) echo "Tuesday" ;;


esac
